package kr.smhrd.model;

public class myUtil {
	
	public int hap(int su1, int su2) {
		int sum=0;
		for(int i =su1; i<=su2; i++) {
			sum+=i;
			
		}
		return sum;
	}
	

}
