package kr.smhrd.model;
import java.sql.*;
import java.util.ArrayList;
// JDBC
public class MemberDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	private void getConnetct() {
		String URL = "jdbc:oracle:thin:@localhost:1521:XE";
		String user = "hr";
		String password = "hr";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//�����ε� �� �ϴ°�?
			
			conn = DriverManager.getConnection(URL, user, password);
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	private void dbClose() {
		try {
			
			if(rs !=null)rs.close();
			if(ps !=null)ps.close();
			if(conn !=null)conn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int MemberInsert(MemberVO vo) {
		getConnetct();
		
		String SQL = "insert into tblMem(num, id, pass, name, tel, email, addr)" 
		+ "values(num_seq.nextval, ?,?,?,?,?,?)";
		int cnt = -1;
		
		try {
			ps=conn.prepareStatement(SQL);
			ps.setString(1, vo.getId());
			ps.setString(2, vo.getPass());
			ps.setString(3, vo.getName());
			ps.setString(4, vo.getTel());
			ps.setString(5, vo.getEmail());
			ps.setString(6, vo.getAddr());
			
			cnt = ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			dbClose();
		}
		return cnt;
		
	}
	public ArrayList<MemberVO> memberAllList() {
		getConnetct();
		String SQL = "select * from tblMem";
		ArrayList<MemberVO> list = new ArrayList<MemberVO>();
		try {
			ps=conn.prepareStatement(SQL);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int num = rs.getInt("num");
				String id = rs.getString("id");
				String pass = rs.getString("pass");
				String name = rs.getString("name");
				String tel = rs.getString("tel");
				String email = rs.getString("email");
				String addr = rs.getString("addr");
				
				MemberVO vo = new MemberVO(num, id, pass, name, tel, email, addr);
				list.add(vo);
				
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}finally {
			dbClose();
		}
		
		return list;
	}
	public int memberDelete(int num) {
		getConnetct();
		String SQL = "delete from tblMem where num=?";
		int cnt= -1;
		try {
			ps=conn.prepareStatement(SQL);
			ps.setInt(1, num);
			cnt = ps.executeUpdate();

		} catch (Exception e) {
			
			e.printStackTrace();
		}finally {
			dbClose();
		}
		
		
		return cnt;
	}
	

}
