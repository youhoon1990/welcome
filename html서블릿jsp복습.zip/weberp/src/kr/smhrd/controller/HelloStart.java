package kr.smhrd.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.smhrd.model.myUtil;

@WebServlet("/hs.do")
public class HelloStart extends HttpServlet {

//	private static final long serialVersionUID = 1L;
//       
//
//    public HelloStart() {
//        super();
//        // TODO Auto-generated constructor stub
//    }

	// �� ���� Ŭ���̾�Ʈ�� �Է� �޾Ƽ� �μ� ������ ������ ���Ͽ� ���Ͻÿ�.

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int su1 = Integer.parseInt(request.getParameter("su1"));
		int su2 = Integer.parseInt(request.getParameter("su2"));

		myUtil my = new myUtil();
		int sum = my.hap(su1, su2);

		response.setContentType("text/html;charset=euc-kr");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println(su1+"~"+su2+"������ ���� = "+sum);
		out.println("</body>");
		out.println("</html>");

	}

}
