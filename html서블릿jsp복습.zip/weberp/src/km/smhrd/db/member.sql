create table tblMem(
	num number not null,
	id varchar2(20) not null primary key,
	pass varchar2(20) not null,
	name varchar2(20) not null,
	tel varchar2(20),
	email varchar2(30),
	addr varchar2(100)
)



create sequence num_seq;

insert into tblMem
values(num_seq.nextval, 'admin', 'admin', '������', '010-7504-1975', 'youhoon1990@naver.com', '���� ����');

select * from tblMem;

