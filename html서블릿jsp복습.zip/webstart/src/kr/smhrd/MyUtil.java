package kr.smhrd;

public class MyUtil {
	
	public int sum() {
		int sum = 0;
		
		for(int i =1; i<=100; i++) {
			sum=sum+i;
		}
		return sum;
	}
	

}
